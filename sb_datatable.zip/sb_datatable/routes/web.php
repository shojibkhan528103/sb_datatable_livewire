<?php

use App\Livewire\Userdatatable;
// test table 
Route::get('/table/datatable/test',Userdatatable::class);
